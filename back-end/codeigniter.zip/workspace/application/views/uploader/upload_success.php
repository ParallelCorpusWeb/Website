<h3>Your files were successfully uploaded!</h3>

<?php foreach ($upload_file as $file):?>
    <ul>
        <li><?=$file['category']?> -- <?=$file['name']?></li>
    </ul>
<?php endforeach; ?>

<p><?php echo anchor('upload', 'Upload Other Files!'); ?></p>