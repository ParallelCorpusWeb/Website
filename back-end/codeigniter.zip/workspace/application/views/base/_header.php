<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
    <head>
        <title>CP Translation Robot (Alpha)</title>
        <link rel="stylesheet" href="/styles/style.css" type="text/css" />
        <meta charset="utf-8">
    </head>
    <body>
        <header>
            <h1>CP Translation Robot (Alpha)</h1>
        </header>
        <nav>
            <ul>
                <li><a href="/index.php/welcome">Home</a></li>
                <?php if ($this->session->userdata('user')) :?>
                    <li><a href="/index.php/file">Files</a></li>
                    <li><a href="/index.php/upload">upload files</a></li>
                <?php endif;?>
                <ul>
                    <?php 
                    if ($this->session->userdata('user')) :?>
                        <li><a href="/index.php/user/setting"><?=$this->session->userdata('user')->name?></a></li>
                        <li><a href="/index.php/user/logout">Logout</a></li>
                    <?php else:?>
                        <li><a href="/index.php/user">Login</a></li>
                    <?php endif;?>
                </ul>
            </ul>
        </nav>
        <div id="container">
    	<h1><?php echo $title;?></h1>
    	<div id="body">
    