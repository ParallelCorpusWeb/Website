<?php echo validation_errors(); ?>

<?php echo form_open('user/register'); ?>

<div>
    <label>Username
        <input type="text" name="username" value="<?php echo set_value('username'); ?>" placeholder="e.g. example@gmail.com"/>
    </label>
</div>
<div>
    <label>Password
        <input type="password" name="password" value="" placeholder="At least 8 characters"/>
    </label>
</div>
<div>
    <label>Password Confirm
        <input type="password" name="passconf" value="" placeholder="Enter your password again"/>
    </label>
</div>
<div>
    <label>Name
        <input type="text" name="name" value="<?php echo set_value('email'); ?>" placeholder="e.g. Chan Tai Men"/>
    </label>
</div>
<div><input type="submit" value="Sign up" /></div>
<p><?php echo anchor('user/login', 'Using existing account.'); ?></p>

</form>