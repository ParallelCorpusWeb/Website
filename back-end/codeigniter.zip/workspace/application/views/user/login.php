<?php echo $error;?>
<?php echo validation_errors(); ?>
<?php echo form_open('user/login'); ?>
<div>
    <label>Username
        <input type="text" name="username" value="<?php echo set_value('username'); ?>"/>
    </label>
</div>

<div>
    <label>Password
        <input type="password" name="password" value=""/>
    </label>
</div>

<div><input type="submit" value="Submit" /></div>
</form>


<p><?php echo anchor('user/register', 'Create a new account.'); ?></p>