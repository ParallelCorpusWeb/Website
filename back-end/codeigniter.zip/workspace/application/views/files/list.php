<?php
    if(!isset($files)||$files==null):
?>
        <span class="message">No files has been uploaded.</span>
<?php else:?>
    <a href="/index.php/file/clear">clear files</a>
    <table>
        <thead>
            <tr>
                <th>
                    Filename
                </th>
                <th>
                    Status
                </th>
                <th>
                    Actions
                </th>
            </tr>
        </thead>
        <tbody>
<?php
    foreach($files as $file):
        $name=$file->rid;
        $status=$file->bilingual==""?"Not finished":"Fnished";
?>
            <tr>
                <td><?=$name?></td>
                <td><?=$status?></td>
                <td>
                    <a href="<?=site_url("file/details/".$name)?>">View</a>
                    <a href="<?=site_url("file/delete/".$name)?>">Delete</a>
                </td>
            </tr>

<?php endforeach;?>
        </tbody>
    </table>
<?php endif;?>