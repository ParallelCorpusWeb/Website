<?php
    $name=$file->rid;
    $cn= str_replace("\\r\\n", chr(13).chr(10),$file->chinese);
    $pt= str_replace("\\r\\n", chr(13).chr(10),$file->portuguese);
    $mix=str_replace("\\r\\n", chr(13).chr(10),$file->bilingual);
    $status=$file->status;
    
    $chinese = array(
      'name' => 'cn',
      'value'=> $cn,
      'rows' => '30',
    );
    $portuguese = array(
      'name' => 'pt',
      'value'=> $pt,
      'rows' => '30',
    );
    $bilingual = array(
      'name' => 'mix',
      'value'=> $mix,
      'rows' => '20',
    );
?>
<p>Source files:</p>
<div class="files">
    <?=form_textarea($chinese)?>
    <?=form_textarea($portuguese)?>
</div>
<p>Target file:</p>
<?=form_open('file/update')?>
    <?=form_hidden('id', $name)?>
    <div class="files">
        <?=form_textarea($bilingual)?>
    </div>
    <?=form_submit("submit","save")?>
    <p><?php echo anchor('file', 'Back'); ?></p>
</form>
            
