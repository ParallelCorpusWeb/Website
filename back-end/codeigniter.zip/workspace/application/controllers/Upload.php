<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	 
	public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                if(!$this->session->userdata('user')){
                        redirect('/user');
                }
        }

        public function index()
        {
		$data['title']="Upload files";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_form', array('error' => ' ' ));
		$this->load->view('base/_footer');
        }

        public function showError($err)
        {
                $data['title']="Upload files";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_form', array('error' => $err));
		$this->load->view('base/_footer');
        }
        
        public function showSuccess($data)
        {
                $data['title']="Upload success";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_success', $data);
		$this->load->view('base/_footer');
        }

        public function do_upload()
        {
                $filename_cn=$_FILES['cn']['name'];
                $filename_pt=$_FILES['pt']['name'];
                $ext_cn=strtoupper(PATHINFO($filename_cn,PATHINFO_EXTENSION));
                $ext_pt=strtoupper(PATHINFO($filename_pt,PATHINFO_EXTENSION));
                $file_cn=$_FILES['cn']['tmp_name'];
                $file_pt=$_FILES['pt']['tmp_name'];
                if(empty($filename_cn)&&empty($filename_pt)){
                        $this->showError('<p>Please select txt files to upload.</p>');
        		return;
                }
                
                $allow_types=['TXT'];
                if(!in_array($ext_cn,$allow_types)||!in_array($ext_pt,$allow_types)){
                        $this->showError('<p>Sorry. Only allow '.implode(", ",$allow_types).' file.</p>');
        		return;
                }
                
                $cn=file_get_contents($file_cn);
                $pt=file_get_contents($file_pt);
                $data['upload_file'][]=array('category'=>'Chinese','name'=>$filename_cn);
                $data['upload_file'][]=array('category'=>'Portuguese','name'=>$filename_pt);
                
        //upload success
                //save to db        
		$this->load->model('file_model');
                $this->file_model->insert($cn,$pt);
                
                //show success
                $this->showSuccess($data);
                
        }
	
}


    