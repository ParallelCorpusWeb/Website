<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_model extends CI_Model {

	
	public function __construct()
    {
            parent::__construct();
            
    }

    public function getAll()
    {
        $query= $this->db->get('raw_data');
        return $query->result();
    }

    public function get($id){
        $query= $this->db->get_where('raw_data', array('rid' => $id));
        return $query->row();
    }
    
    public function insert($cn,$pt){
        $cn=$this->db->escape_str($cn);
        $pt=$this->db->escape_str($pt);
        $this->db->insert('raw_data', array('chinese'=>$cn,'portuguese'=>$pt));
    }
    
    public function update($mix,$id){
        $mix=$this->db->escape_str($mix);
        $id=$this->db->escape_str($id);
        $this->db->where('rid', $id);
        $this->db->update('raw_data', array('bilingual'=>$mix));
    }
    
    public function delete($id){
        $id=$this->db->escape_str($id);
        $this->db->delete('raw_data', array('rid' => $id));
    }
    
    public function clear(){
        $this->db->truncate('raw_data');
    }
        
}


    