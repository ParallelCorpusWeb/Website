<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_model extends CI_Model {

	
	public function __construct()
    {
            parent::__construct();
            
    }

    public function getAll()
    {
        $query= $this->db->query("SELECT * FROM raw_data");
        return $query->result();
    }

    public function get($id){
        $sql= "SELECT * FROM raw_data WHERE rid=?";
        $query= $this->db->query($sql, array($id));
        return $query->row();
    }
    
    public function insert($cn,$pt){
        $cn=$this->db->escape_str($cn);
        $pt=$this->db->escape_str($pt);
        $sql= "INSERT INTO raw_data(chinese,portuguese) VALUES (?,?)";
        $this->db->query($sql, array($cn,$pt));
    }
    
    public function update($mix,$id){
        $mix=$this->db->escape_str($mix);
        $id=$this->db->escape_str($id);
        $sql= "UPDATE raw_data SET bilingual=? WHERE rid=?";
        $query= $this->db->query($sql, array($mix,$id));
    }
    
    public function delete($id){
        $id=$this->db->escape_str($id);
        $sql= "DELETE FROM raw_data WHERE rid=?";
        $query= $this->db->query($sql, array($id));
    }
    
    public function clear(){
        $this->db->query("TRUNCATE TABLE raw_data");
    }
        
}


    