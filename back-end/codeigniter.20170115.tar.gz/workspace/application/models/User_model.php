<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	
	public function __construct()
    {
            parent::__construct();
            
    }

    public function getAll()
    {
        $query= $this->db->get('account');
        return $query->result();
    }

    public function get($id){
        $query= $this->db->get_where('account', array('uid' => $id));
        return $query->row();
    }
    
    public function insert($ac,$pw,$name){
        $ac=$this->db->escape_str($ac);
        $pw=$this->db->escape_str($pw);
        $name=$this->db->escape_str($name);
        $pw=do_hash($pw);
        $this->db->insert('account', 
        array('username'=>$ac,'password'=>$pw,'name'=>$name));
    }
    
    public function updatePassword($id,$pw){
        $id=$this->db->escape_str($id);
        $pw=$this->db->escape_str($pw);
        $this->db->where('uid', $id);
        $this->db->update('account', array('password'=>do_hash($pw)));
    }
    
    public function delete($id){
        $id=$this->db->escape_str($id);
        $this->db->delete('account', array('uid' => $id));
    }
    
    public function getUserByNamePassword($ac,$pw){
        $ac=$this->db->escape_str($ac);
        $pw=$this->db->escape_str($pw);
        $query= $this->db->get_where('account', array('username' => $ac,'password'=>do_hash($pw)));
        return $query->row();
    }
    
    public function is_auth($ac,$pw){
        $ac=$this->db->escape_str($ac);
        $pw=$this->db->escape_str($pw);
        $query= $this->db->get_where('account', array('username' => $ac));
        $existing_ac = $query->row();
        if(!empty($existing_ac)&&!empty($ac)&&!empty($pw)&& $ac===$existing_ac->username && do_hash($pw)===$existing_ac->password){
            return true;
        }else{
            return false;
        }
    }
        
}


    