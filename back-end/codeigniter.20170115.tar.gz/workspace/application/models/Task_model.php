<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task_model extends CI_Model {
	
	private $table='task';
	
	public function __construct()
    {
            parent::__construct();
    }

    public function getAll()
    {
        $query= $this->db->get($this->table);
        return $query->result();
    }

    public function getAllBy($uid)
    {
        $query= $this->db->get_where($this->table, array('uid' => $uid));
        return $query->result();
    }

    public function get($id){
        $query= $this->db->get_where($this->table, array('tid' => $id));
        return $query->row();
    }
    
    public function getDoer($rid){
        $query= $this->db->get_where($this->table, array('rid' => $rid));
        return $query->row();
    }
    
    public function countDoingTasks($uid)
    {
        $query= $this->db->get_where($this->table, array('uid' => $uid, 'end_at' => NULL));
        return $query->num_rows();
    }
    
    public function insert($uid,$rid){
        $uid=$this->db->escape_str($uid);
        $rid=$this->db->escape_str($rid);
        $this->db->insert($this->table, array('uid'=>$uid,'rid'=>$rid));
    }
    
    public function update($bilingual_after,$rid){
        $bilingual_after=$this->db->escape_str($bilingual_after);
        $rid=$this->db->escape_str($rid);
        $this->db->where('rid', $rid);
        $this->db->update($this->table, array('bilingual_after'=>$bilingual_after));
        
    }
    
    public function delete($id){
        $id=$this->db->escape_str($id);
        $this->db->delete($this->table, array('tid' => $id));
    }
        
}


    