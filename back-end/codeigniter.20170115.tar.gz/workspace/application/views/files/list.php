<?php
    if(!isset($files)||$files==null):
?>
        <span class="message">No files has been uploaded.</span>
<?php else:?>
    <a href="/index.php/file/clear">clear files</a>
    <table>
        <thead>
            <tr>
                <th>
                    Filename
                </th>
                <th>
                    Status
                </th>
                <th>
                    Actions
                </th>
            </tr>
        </thead>
        <tbody>
<?php
    foreach($files as $file):
        $name=$file->rid;
        $status=$file->status==""?"Not finished":$file->status;
?>
            <tr>
                <td><?=$name?></td>
                <td><?=$status?></td>
                <td>
                    <a href="<?=site_url("file/details/".$name)?>">View</a>
                    <?php 
                        if($this->session->userdata('user')->authority == "student")
                        {
                            
                        }else{
                            echo anchor('file/delete/'.$name, 'Delete', 
                                array('onclick' => "return confirm('Are you sure want to delete this file?')"));
                        }
                    ?>
                </td>
            </tr>

<?php endforeach;?>
        </tbody>
    </table>
<?php endif;?>