<p>Hello, <?=$user->name?>.</p>

<div>Average grade: <?=$user->avg_grade==null?"--":$user->avg_grade?></div>
<div>Sentence amount: <?=$user->sentence_amount?></div>

<p><?php echo anchor('user/password/change', 'Change password'); ?></p>