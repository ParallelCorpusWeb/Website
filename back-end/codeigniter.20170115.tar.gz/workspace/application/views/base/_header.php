<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
    <head>
        <title>CP Translation Robot (Alpha)</title>
        <link rel="stylesheet" href="/styles/style.css" type="text/css" />
        <meta charset="utf-8">
        <meta name="viewpoint" content="device-width initial-scal=1.0">
    </head>
    <body>
        <header>
            <h1>CP Translation Robot (Alpha)</h1>
        </header>
        <nav>
            <ul>
                <li><?php echo anchor('welcome', 'Home'); ?></li>
                <?php if ($this->session->userdata('user')) :?>
                    <li><?php echo anchor('file', 'Files'); ?></li>
                    <li><?php echo anchor('task', 'Tasks'); ?></li>
                    <?php if ($this->session->userdata('user')->authority == "teacher") :?>
                        <li><?php echo anchor('upload', 'upload files'); ?></li>
                    <?php endif;?>
                <?php endif;?>
                <ul>
                    <?php 
                    if ($this->session->userdata('user')) :?>
                        <li><?php echo anchor('user/setting', $this->session->userdata('user')->name); ?></li>
                        <li><?php echo anchor('user/logout', 'Logout'); ?></li>
                    <?php else:?>
                        <li><?php echo anchor('user', 'Login'); ?></li>
                    <?php endif;?>
                </ul>
            </ul>
        </nav>
        <div id="container">
    	<h1><?php echo $title;?></h1>
    	<div id="body">
    