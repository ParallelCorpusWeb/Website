<?php echo $error;?>
<?php echo form_open_multipart('upload/do_upload');?>
    <div>
            <lebel for="cn">Chinese txt: </lebel>
            <input name="cn" id="cn" type="file"/>  
    </div>
    <div>
            <lebel for="pt">Portuguese txt: </lebel>
            <input name="pt" id="pt" type="file"/>  
    </div>
    <input type="submit" name="submit" value="upload" />
</form>