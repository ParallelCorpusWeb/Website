<?php
    if(!isset($tasks)||$tasks==null):
?>
        <span class="message">No tasks has been taken.</span>
<?php else:?>
    <table>
        <thead>
            <tr>
                <th>
                    Task
                </th>
                <th>
                    Percentage
                </th>
                <th>
                    Actions
                </th>
            </tr>
        </thead>
        <tbody>
<?php
    foreach($tasks as $task):
        $name=$task->tid;
        $percentage=$task->percentage;
?>
            <tr>
                <td><?=$name?></td>
                <td><?=$percentage?></td>
                <td>
                    <a href="<?=site_url("file/details/".$name)?>">View</a>
                    <?php 
                        if($this->session->userdata('user')->authority == "student")
                        {
                            
                        }else{
                            echo anchor('file/delete/'.$name, 'Delete', 
                                array('onclick' => "return confirm('Are you sure want to delete this file?')"));
                        }
                    ?>
                </td>
            </tr>

<?php endforeach;?>
        </tbody>
    </table>
<?php endif;?>