<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'security'));
        $this->load->model('user_model');
    }
	 
	public function index()
	{
	    //not logged in
		    $this->login();
		//logged in
		    //to do: show home page
	}
	
	public function login()
	{
	    if($this->session->userdata('user')){
                redirect('/');
        }
            
	    $data['error']="";
	    $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
       
        if ($this->form_validation->run() == FALSE)
        {
    	    $data['title']="Login";
    		$this->load->view('base/_header',$data);
    		$this->load->view('user/login',$data);
    		$this->load->view('base/_footer');
        }
        else
        {
            $ac=$this->input->post('username');
            $pw=$this->input->post('password');
            if($this->user_model->is_auth($ac,$pw)){
                $user=$this->user_model->getUserByNamePassword($ac,$pw);
                $this->session->set_userdata('user', $user);
                $this->success('Login successfully.');
            }else{
                $data['error']="<p>Username or Password is not valid.</p>";
                $data['title']="Login";
        		$this->load->view('base/_header',$data);
        		$this->load->view('user/login',$data);
        		$this->load->view('base/_footer');
            }
        }
	}
	
	public function logout(){
	    $this->session->unset_userdata('user');
        $this->session->sess_destroy();
        $this->success("Logout Successfully.");
	}
	
	public function setting(){
	    if(!$this->session->userdata('user')){
                redirect('/user');
        }
	    $data['user']=$this->session->userdata('user');
	    $data['title']="Setting";
		$this->load->view('base/_header',$data);
		$this->load->view('user/setting',$data);
		$this->load->view('base/_footer');
	}
	
	public function password($change){
	    if(!$this->session->userdata('user')){
                redirect('/user');
        }
        
	    if($change!="change"){
                redirect('user/password/change');
        }
        $data['error']="";
        $this->load->library('form_validation');
        $this->form_validation->set_rules('opassword', 'Current Password', 'trim|required|xss_clean',
        array('required'=>"Your Current Password is required."));
        $this->form_validation->set_rules('password', 'New Password', 'trim|required|xss_clean|min_length[8]');
        $this->form_validation->set_rules('passconf', 'New Password Confirmation', 'trim|required|xss_clean|matches[password]',
        array('matches'=>"New Password Confirmation does not match the new password."));
       
        if ($this->form_validation->run() == FALSE)
        {
    	    $data['title']="Change password";
    		$this->load->view('base/_header',$data);
    		$this->load->view('user/password',$data);
    		$this->load->view('base/_footer');
    	}
    	else
        {
            $id=$this->session->userdata('user')->uid;
            $ac=$this->session->userdata('user')->username;
            $opw=$this->input->post('opassword');
            $pw=$this->input->post('password');
            if($this->user_model->is_auth($ac,$opw)){
                $this->user_model->updatePassword($id,$pw);
                $this->success('Change password successfully.');
            }else{
                $data['error']="<p>Current password does not match.</p>";
                $data['title']="Change password";
        		$this->load->view('base/_header',$data);
        		$this->load->view('user/password',$data);
        		$this->load->view('base/_footer');
            }
        }
	}
	
	public function Register()
	{
	    if($this->session->userdata('user')){
                redirect('/');
        }
	    
	    $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean|valid_email|is_unique[account.username]',
        array('is_unique'=>"Your %s has been used. Please try another one."));
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|min_length[8]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|xss_clean|matches[password]',
        array('matches'=>"Password Confirmation does not match the password."));
        $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE)
        {
    	    $data['title']="Register";
    		$this->load->view('base/_header',$data);
    		$this->load->view('user/register');
    		$this->load->view('base/_footer');
        }
        else
        {
            $ac=$this->input->post('username');
            $pw=$this->input->post('password');
            $name=$this->input->post('name');
            $this->user_model->insert($ac,$pw,$name);
            $this->success('Create account successfully.');
        }
	}
	
	
	public function success($message){
		$data['title']="Success";
		$data['message']=$message;
		$this->load->view('base/_header',$data);
		$this->load->view('user/success',$data);
		$this->load->view('base/_footer');
	}
	
}


    