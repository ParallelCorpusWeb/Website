<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'security'));
        $this->load->model('file_model');
        $this->load->model('task_model');
	    if(!$this->session->userdata('user')){
                redirect('/user');
        }
    }
	 
	public function index()
	{
	    $uid=$this->session->userdata('user')->uid;
	    $data['tasks']=$this->task_model->getAllBy($uid);
		$data['title']="Tasks";
		$this->load->helper('url');
		$this->load->view('base/_header',$data);
		$this->load->view('tasks/list',$data);
		$this->load->view('base/_footer');
	}
	
	public function take()
	{
	    $rid=$this->input->post('rid');
	    $uid=$this->session->userdata('user')->uid;
	    if($this->task_model->countDoingTasks($uid)<5){
	    	$this->task_model->insert($uid,$rid);
        	$this->file_model->update($rid,"Processing");
        	$this->message('Success','Take task successfully.');
	    }else{
        	$this->message('Notice','You can only task 5 tasks at the same time.');
	    }
	}
	
	public function message($title,$message){
		$data['title']=$title;
		$data['message']=$message;
		$this->load->view('base/_header',$data);
		$this->load->view('base/message',$data);
		$this->load->view('base/_footer');
	}
	
	public function submit(){
		$action=$this->input->post('submit');
		if($action=="Update"){
			$rid=$this->input->post('rid');
			$bilingual_after=$this->input->post('result');
			$this->task_model->update($bilingual_after,$rid);
			$this->message('Success','Update task successfully.');
		}else if($action=="Finish"){
			//set status
			//end at
		}
	}
	
}


    