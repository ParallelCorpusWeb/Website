
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>CPE LABORATORY</title>
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<script src="Javascript/Flot/excanvas.js"></script>
	<![endif]-->
	<link rel="icon" type="image/jpg" href="Images/lab_icon_favicon.png" />
	<!-- The Main CSS File -->
	<link rel="stylesheet" href="CSS/style.css">
	<!-- jQuery -->
	<script src="Javascript/jQuery/jquery-1.7.2.min.js"></script>
	<!-- Flot -->
	<script src="Javascript/Flot/jquery.flot.js"></script>
	<script src="Javascript/Flot/jquery.flot.resize.js"></script>
	<script src="Javascript/Flot/jquery.flot.pie.js"></script>
	<!-- DataTables -->
	<script src="Javascript/DataTables/jquery.dataTables.min.js"></script>
	<!-- ColResizable -->
	<script src="Javascript/ColResizable/colResizable-1.3.js"></script>
	<!-- jQuryUI -->
	<script src="Javascript/jQueryUI/jquery-ui-1.8.21.min.js"></script>
	<!-- Uniform -->
	<script src="Javascript/Uniform/jquery.uniform.js"></script>
	<!-- Tipsy -->
	<script src="Javascript/Tipsy/jquery.tipsy.js"></script>
	<!-- Elastic -->
	<script src="Javascript/Elastic/jquery.elastic.js"></script>
	<!-- ColorPicker -->
	<script src="Javascript/ColorPicker/colorpicker.js"></script>
	<!-- SuperTextarea -->
	<script src="Javascript/SuperTextarea/jquery.supertextarea.min.js"></script>
	<!-- UISpinner -->
	<script src="Javascript/UISpinner/ui.spinner.js"></script>
	<!-- MaskedInput -->
	<script src="Javascript/MaskedInput/jquery.maskedinput-1.3.js"></script>
	<!-- ClEditor -->
	<script src="Javascript/ClEditor/jquery.cleditor.js"></script>
	<!-- Full Calendar -->
	<script src="Javascript/FullCalendar/fullcalendar.js"></script>
	<!-- Color Box -->
	<script src="Javascript/ColorBox/jquery.colorbox.js"></script>
	<!-- Kanrisha Script -->
	<script src="Javascript/kanrisha.js"></script>
</head>
<body>
	
	<header class="main_header">
		<div class="wrapper">
			<div class="logo">
				<a href="#" title="CPE LABORATOYR">
					<img src="Images/logo.png" alt="CPE LABORATOYR" />
				</a>
			</div>

		</div>
	</header>

	<div class="wrapper small_menu">
		<ul class="menu_small_buttons">
			<li><a title="General Info" class="i_22_forms" href="index_teacher.html"></a></li>
			<li><a title="Your Messages" class="i_22_charts smActive" href="grade_teacher.html"></a></li>
			<li><a title="Kit elements" class="i_22_dashboard" href="profile_teacher.html"></a></li>
			<li><a title="Some Rows" class="i_22_tables bdcC" href="logout.html"></a></li>
		</ul>
	</div>

	<div class="wrapper contents_wrapper">
		
		<aside class="sidebar">
			<ul class="tab_nav">
				<li class="i_32_formsw">
					<a href="index_teacher.html" title="My Task">
						<span class="tab_label" style="color:#f9f9f9">Tasks</span>
						<span class="tab_info" style="color:#f9f9f9">My Task</span>
					</a>
				</li>
				<li class="active_tab i_32_charts">
					<a href="grade_teacher.html" title="View Score">
						<span class="tab_label">Grade</span>
						<span class="tab_info">View Score</span>
					</a>
				</li>
				<li class="i_32_dashboardw">
					<a href="profile_teacher.html" title="My Information">
						<span class="tab_label" style="color:#f9f9f9">Profile</span>
						<span class="tab_info" style="color:#f9f9f9">My Info</span>
					</a>
				</li>
				<li class="bdcC i_32_tablesw">
					<a href="#" title="Exit System">
						<span class="tab_label" style="color:#f9f9f9">Logout</span>
						<span class="tab_info" style="color:#f9f9f9">Exit System</span>
					</a>
				</li>
			</ul>
		</aside>

		</aside>
		<div class="contents">
			<div class="grid_wrapper">

				<div class="g_6 contents_header">
					<h3 class="i_16_charts tab_label">Grade</h3>
					<div><span class="label">View the grades of students and the detial of each task</span></div>
				</div>

				<div class="g_12 separator"><span></span></div>

				<div class="g_12">
					<div class="widget_header">
						<h4 class="widget_header_title wwIcon i_16_tooltip">Completed Tasks</h4>
					</div>
					<div class="widget_contents noPadding twCheckbox">
						<table class="tables datatable noObOLine">
							<thead>
								<tr>
									<th>ID</th>
									<th>Title</th>
									<th>Grade</th>
									<th>Student</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
								<tr class="status_open">
									<td>#238749</td>
									<td>aaaaaaaaaaaaaaaaaaaaaaaaaaa</td>
									<td>High</td>
									<td>AAAA</td>
									<td>2016/10/20</td>
								</tr>
								<tr class="status_open">
									<td>#238750</td>
									<td>bbbbbbbbbbbbbbbbbbbbbbbbbbbb</td>
									<td>Low</td>
									<td>OOOOO</td>
									<td>2016/10/20</td>
								</tr>
								<tr class="status_open">
									<td>#238751</td>
									<td>cccccccccccccccccccccccccccc</td>
									<td>Medium</td>
									<td>AAAA</td>
									<td>2016/10/20</td>
								</tr>
								<tr class="status_closed">
									<td>#238752</td>
									<td>ddddddddddddddddddddddddddddd</td>
									<td>Low</td>
									<td>ppppp</td>
									<td>2016/10/20</td>
								</tr>
								<tr class="status_closed">
									<td>#238753</td>
									<td>eeeeeeeeeeeeeeeeeeeeeeeeeeeeeee</td>
									<td>Medium</td>
									<td>ASSS</td>
									<td>2016/10/20</td>
								</tr>
								<tr class="status_closed">
									<td>#238754</td>
									<td>fffffffffffffffffffffffffffffff</td>
									<td>High</td>
									<td>Aplj</td>
									<td>2016/10/20</td>
								<tr class="status_closed">
									<td>#238755</td>
									<td>ggggggggggggggggggggggggggggggg</td>
									<td>Low</td>
									<td>ALLA</td>
									<td>2016/10/22</td>
								</tr>
								<tr class="status_closed">
									<td>#238756</td>
									<td>hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh</td>
									<td>High</td>
									<td>APPA</td>
									<td>2016/10/27</td>
								</tr>
								<tr class="status_closed">
									<td>#238757</td>
									<td>iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii</td>
									<td>Medium</td>
									<td>AddA</td>
									<td>2016/10/15</td>
								</tr>
								<tr class="status_closed">
									<td>#238758</td>
									<td>jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj</td>
									<td>High</td>
									<td>AppA</td>
									<td>2016/11/01</td>
								</tr>
								<tr class="status_closed">
									<td>#238757</td>
									<td>kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk</td>
									<td>Medium</td>
									<td>APPA</td>
									<td>2016/10/15</td>
								</tr>
								<tr class="status_closed">
									<td>#238758</td>
									<td>lllllllllllllllllllllllllllllllllll</td>
									<td>High</td>
									<td>PPAP</td>
									<td>2016/11/01</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>		
		</div>
	</div>

	<div class="dialog dConf" title="Logout"><span class="label lwParagraph" style="font-size: 110%">Are you sure you want to logout this system ?</span></div>

	<footer>
		<div class="wrapper">
			<span class="copyright">
				© 2016 Macao Polytechnic Institute. All Rights Reserved. Designed By Macao Polytechnic Institute
			</span>
		</div>
	</footer>
</body>
</html>