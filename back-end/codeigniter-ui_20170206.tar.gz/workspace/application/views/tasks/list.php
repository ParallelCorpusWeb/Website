<div class="contents">
	<div class="grid_wrapper">

		<div class="g_6 contents_header">
			<h3 class="i_16_forms tab_label">Tasks</h3>
			<div><span class="label">Tasks Information</span></div>
		</div>

		<div class="separator g_12"><span></span></div>
		<!--Warming-->

		<div class="g_12"><div class="error iDialog">Plaese finish your tasks before deadline.<a href="#" style="text-decoration: underline;color: #2f14ff;">I GOT IT</a></div></div>

		<!--get new task-->
		<div class="g_2 contents_header"></div>
		<div class="g_4 contents_header">
			<h3 class="i_16_forms tab_label">My Tasks:<span style="color:red;"><?=$numOfTasks?>/5</span></h3>
			<div><span class="label">You can pick up 5 tasks at most.</span></div>
		</div>
		 
		<div class="g_4 contents_options">
			<div class="simple_buttons">
				<?=anchor("file","Get new task",
				array('class'=>"bwIcon i_16_help",'style'=>"font-size: large"))?>
			</div>
		</div>

		

         <div class="g_2 contents_header"></div>

		<div class="g_12 separator"><span></span></div>

       <!-- uncompleted tasks -->
		<div class="g_12">
			<div class="widget_header">
				<h4 class="widget_header_title wwIcon i_16_forms">My Tasks</h4>
			</div>
			<div class="widget_contents noPadding">
				<table class="tables">
					<thead>
						<tr>
							<th>ID</th>
							<th>Title</th>
							<th>Date</th>
							<th width="15">Percentage</th>
							<th width="15%">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
							if(count($tasks)<1):
						?>
							<tr><td colspan="5" align="center">You haven't got any tasks.</td></tr>
						<?php else:
								foreach($tasks as $task):
								$rid=$task->rid;
								$percentage=$task->percentage;
								$start_at=date_create($task->start_at);
						?>
							<tr>
								<td><?=$rid?></td>
								<td>--</td>
								<td><?=date_format($start_at, 'Y/m/d');?></td>
								<td><?=$percentage?>%</td>
								<td align="center"><!--valign="center"-->
								<div class="simple_buttons">
								<?php
									if($task->end_at==null){
										echo anchor('file/details/'.$rid,'<div>Work</div>');
									}else{
										echo anchor('file/details/'.$rid,'<div>View</div>');
									}
								?>
								</div>
								</td>
							</tr>
						<?php endforeach;endif;?>
						
						
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
