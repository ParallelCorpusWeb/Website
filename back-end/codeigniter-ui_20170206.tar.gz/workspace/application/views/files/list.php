<div class="contents">
	<div class="grid_wrapper">

		<div class="g_6 contents_header">
			<h3 class="i_16_forms tab_label">Tasks</h3>
			<div><span class="label">Tasks Information</span></div>
		</div>

		<div class="separator g_12"><span></span></div>

       <!-- uncompleted tasks -->
		<div class="g_12">
			<div class="widget_header">
				<h4 class="widget_header_title wwIcon i_16_tooltip">All Tasks</h4>
			</div>
			<div class="widget_contents noPadding twCheckbox">
				<table class="tables datatable noObOLine">
					<thead>
						<tr>
							<th>ID</th>
							<th>Title</th>
							<th>Date</th>
							<th>Status(worker)</th>
							<th width="10%">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($files as $file):
							$rid=$file->rid;
							$status=$file->status==""?"Not finished":$file->status;
							$class=$file->status==""?"status_open":"status_closed";
							$action=$file->status==""?'work':'view';
							$date=$file->start_at==""?"--/--/--":date_format(date_create($file->start_at),'Y/m/d');
						?>
						
						<tr class="<?=$class?>">
							<td align="center">#<?=$rid?></td>
							<td align="center">--</td>
							<td align="center"><?=$date?></td>
							<td align="center"><?=$status?></td>
							<td align="center"><!--valign="center"-->
							<div class="simple_buttons">
								<?=anchor('file/details/'.$rid,'<div>'.$action.'</div>');?>
							</div>
							</td>
						</tr>
						<?php endforeach;?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>