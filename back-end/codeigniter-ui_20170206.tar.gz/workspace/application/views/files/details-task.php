<?php
var_dump($file);
    $name=$file->rid;
    $cn= str_replace("\\r\\n", chr(13).chr(10),$file->chinese);
    $pt= str_replace("\\r\\n", chr(13).chr(10),$file->portuguese);
    $mix=str_replace("\\r\\n", chr(13).chr(10),$file->bilingual);
    $status=$file->status;
    
    if(!$doer){
      $bilingual_after='';
    }else{
      $bilingual_after=$doer->bilingual_after;
    }
    
    $chinese = array(
      'name' => 'cn',
      'value'=> $cn,
      'rows' => '30',
      'readonly'=>'readonly'
    );
    $portuguese = array(
      'name' => 'pt',
      'value'=> $pt,
      'rows' => '30',
      'readonly'=>'readonly'
    );
    $bilingual = array(
      'name' => 'mix',
      'value'=> $mix,
      'rows' => '30',
      'readonly'=>'readonly'
    );
    $result = array(
      'name' => 'result',
      'value'=> $bilingual_after,
      'rows' => '30'
    );
?>
<p>Single language files:</p>
<div class="files">
    <?=form_textarea($chinese)?>
    <?=form_textarea($portuguese)?>
</div>
<p>Orgainal bilingual:</p>
<div class="files"> 
    <?=form_textarea($bilingual)?>
</div>
<?php 
    if(!$doer):
      echo form_open('task/take');
      echo form_hidden('rid',$name);
      echo form_submit("submit","take task");
    elseif($doer->uid==$this->session->userdata('user')->uid):
      echo form_open('task/submit');
      echo form_hidden('rid',$name);
?>
      <p>Target file:</p>
      <div class="files">
          <?=form_textarea($result)?>
      </div>
<?php
      echo form_submit("submit","Update");
      echo form_submit("submit","Finish",
        array('onclick' => "return confirm('Are you finish?')"));
      endif;
?>
    <p><?php echo anchor('file', 'Back'); ?></p>
</form>
            
