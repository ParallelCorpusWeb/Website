<?php
    if(!isset($users)||$users==null):
?>
        <span class="message">No new users has been registered.</span>
<?php else:?>
    <table>
        <thead>
            <tr>
                <th>User</th>
                <th>Type</th>
                <th>Average Grade</th>
                <th>Sentence Amount</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
<?php
    foreach($users as $user):
        $name=$user->name;
        $authority=$user->authority==""?"new user":$user->authority;
        $avg_grade=$user->avg_grade==""?"--":$user->avg_grade;
        $sentence_amount=$user->sentence_amount;
?>
            <tr>
                <td><?=$name?></td>
                <td><?=$authority?></td>
                <td><?=$avg_grade?></td>
                <td><?=$sentence_amount?></td>
                <td>--</td>
            </tr>

<?php endforeach;?>
        </tbody>
    </table>
<?php endif;?>