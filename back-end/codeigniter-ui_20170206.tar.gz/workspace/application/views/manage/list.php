
	<div class="contents">
		<div class="grid_wrapper">

			<div class="g_6 contents_header">
				<h3 class="i_16_ui tab_label">CPE administration</h3>
				 <div><span class="label">Members & Tasks</span></div> 
			</div>

			<div class="g_12 separator"><span></span></div>

			<div class="g_12" id="table_wTabs">

			<!--member-->
			<div class="g_6" id="table_wTabs">
				<div class="widget_header wwOptions">
					<h4 class="widget_header_title wwIcon i_16_tabs">Member</h4>
				</div>
				<div class="widget_contents noPadding twCheckbox">
					<table class="tables" id="table_wTabs-2">
						<thead>
							<tr>
								<th style="width: auto;">Member ID</th>
								<th>Name</th>
								<th>Position</th>
								<th>Average grade</th>
							</tr>
						<?php
								foreach ($users as $user):
									$id=$user->uid;
									$name=$user->name;
									$auth=$user->authority;
									$avg_grade=$user->avg_grade;
							?>
								<tr>
									<td><?=$id?></td>
									<td><?=$name?></td>
									<td><?=$auth?></td>
									<td><?=$avg_grade==''?'--':$avg_grade?></td>
								</tr>
							<?php endforeach;?>
						</thead>
						<tbody>
						</tbody>
					</table>						
				</div>
				<div class="simple_buttons" style="margin-top: 10px;">
					<a href="#"><div>More</div></a>
				</div>
			</div>

			<!--tasks-->
			<div class="g_6" id="table_wTabs">
				<div class="widget_header wwOptions">
					<h4 class="widget_header_title wwIcon i_16_tabs">Task</h4>
				</div>
				<div class="widget_contents noPadding twCheckbox">
					<table class="tables" id="table_wTabs-1">
						<thead>
							<tr>
								<th style="width: auto;">Task ID</th>
								<th>Worker</th>
								<th>Percentage</th>									
							</tr>
							
							<?php
								foreach ($tasks as $task):
									$id=$task->tid;
									$name=$task->name;
									$percentage=$task->percentage;
									
							?>
								<tr>
									<td><?=$id?></td>
									<td><?=$name?></td>
									<td><?=$percentage?>%</td>
								</tr>
							<?php endforeach;?>
						</thead>
						<tbody>
						</tbody>
					</table>						
				</div>
				<div class="simple_buttons" style="margin-top: 10px;">
					<!--<a href="tasks_admin.html"><div>More</div></a>-->
					<?=anchor('file','<div>More</div>')?>
				</div>

			</div>


			<!--send message to all-->
			<div class="g_12">
				<div class="widget_header cwhToggle">
					<h4 class="widget_header_title wwIcon i_16_message">Send message to member</h4>
				</div>
				<div class="widget_contents cwClose noPadding">
					<div class="line_grid">
						<div class="g_2">
							<span class="label">To: </span>
						</div>
						<div class="g_10">
							<select class="simple_form">
								<option value="Web Designer" selected="selected" />All
								<option value="Web Developer" />Student
								<option value="Other" />Teacher
							</select>
						</div>
					</div>

					
					<div class="line_grid">
						<div class="g_2">
							<span class="label">Title</span>
						</div>
						<div class="g_10">
							<input type="text" class="simple_field">
						</div>
					</div>
					<div class="line_grid">
						<div class="g_2">
							<span class="label">Message</span>
						</div>
						<div class="g_10">
							<textarea class="simple_field wysiwyg"></textarea>
						</div>	
					</div>
					<div class="line_grid">
						<div class="g_2">
							<span class="label">Files</span>
						</div>
						<div class="g_10">
							<input type="file" class="simple_form">
						</div>
					</div>
					<div class="line_grid">
						<div class="g_12">
							<input type="submit" value="Send" class="simple_buttons submitIt">
						</div>
					</div>
					</div>
				</div>
			</div>

				

			</div>
		</div>		
	</div>



<script src="/Javascript/messages.js"></script>

<script src="/Javascript/getTask.js"></script>
<script type="text/javascript">

	$('body').append('<div class="dialog dConf" title="Logout"><span class="label lwParagraph" style="font-size: 110%">Are you sure you want to logout this system ?</span></div>');

				
	var S=members.getMembers();
	var W=working.getWork();
	var P=paragraph.getParagraph();

	for(var i=0; i<5; i++){
		var $r=$('<tr>').attr('class',"status_open");
		$r.append(`<td>*${S.data[i].wid}</td>`).attr('class',"");
		$r.append(`<td>*${S.data[i].name}</td>`).attr('class',"");
		$r.append(`<td>*${S.data[i].position}</td>`).attr('class',"");
		$r.append(`<td>*${(working.data).filter(s => { return s.wid==S.data[i].wid}).length}</td>`).attr('class',"");
		$('#table_wTabs-2 tbody').append($r);
	}
	for(var i=0; i<5; i++){
		var $r=$('<tr>').attr('class',"status_open");
		$r.append(`<td>*${paragraph.getParagraph(W.data[i].pid).pid}</td>`).attr('class',"");
		$r.append(`<td>*${paragraph.getParagraph(W.data[i].pid).Title}</td>`).attr('class',"");
		$r.append(`<td>*${W.data[i].Percentage}%</td>`).attr('class',"");
		$('#table_wTabs-1 tbody').append($r);
	}

</script>
