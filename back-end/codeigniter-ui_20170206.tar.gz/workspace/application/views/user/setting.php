
<div class="contents">
	<div class="grid_wrapper">

		<div class="g_6 contents_header">
			<h3 class="i_16_dashboard tab_label">Profile</h3>
			<div><span class="label">User Information</span></div>
		</div>
		<!-- 
		<div class="g_6 contents_options">
			<div class="simple_buttons">
				<div class="bwIcon i_16_help">Help</div>
			</div>
			<div class="simple_buttons">
				<div class="bwIcon i_16_settings">Settings</div>
				<div class="buttons_arrow">
					 Drop Menu 
					<ul class="drop_menu menu_with_icons right_direction">
						<li>
							<a class="i_16_add" href="#" title="New Flie">
								<span class="label">New File</span>
							</a>									
						</li>
						<li>
							<a class="i_16_progress" href="#" title="2 Files Left">
								<span class="label">Files Left</span>
								<span class="small_count">2</span>
							</a>
						</li>
						<li>
							<a class="i_16_files" href="#" title="Browse Files">
								<span class="label">Browse Files</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>-->

		<div class="g_12 separator"><span></span></div>

		<!-- Personal Information -->
		<div class="g_12">
			<div class="widget_header">
				<h4 class="widget_header_title wwIcon i_16_dashboard">Personal Information</h4>
			</div>
			<div class="widget_contents noPadding">
				<table class="tables">

					<tbody>
						<tr>
							<th width="40%">Name</th>
							<td width="60%"><?=$user->name?></td>	
						</tr>
						<tr>
							<th>Student ID</th>
							<td>*P1234567</td>
						</tr>
						<tr>
							<th>Year</th>
							<td>*1</td>
						</tr>
						<tr>
							<th>School</th>
							<td>*ESAP</td>
						</tr>
						<tr>
							<th>Specialized Subject</th>
							<td>*Computer Program</td>
						</tr>
						<tr>
							<th>Email</th>
							<td><?=$user->username?></td>
						</tr>

					</tbody>
				</table>
			</div>
		</div>

		<div class="g_12 separator"><span></span></div>

		<!-- Statistical data -->
		<div class="g_4">
			<div class="big_stats visitor_stats">
				<?=$user->avg_grade==null?"--":$user->avg_grade?>
			</div>
			<h5 class="stats_info">Average Grade</h5>
		</div>
		<div class="g_4">
			<div class="big_stats tickets_stats">
				<?=$user->sentence_amount?>
			</div>
			<h5 class="stats_info">Sentence Amount</h5>
		</div>
		<div class="g_4">
			<div class="big_stats users_stats">
				*3
			</div>
			<h5 class="stats_info">Uncompleted Tasks</h5>
		</div>


	</div>
</div>