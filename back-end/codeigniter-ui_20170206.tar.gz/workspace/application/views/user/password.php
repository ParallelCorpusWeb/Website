<?php echo $error;?>
<?php echo validation_errors(); ?>

<?php echo form_open('user/password/change'); ?>

<div>
    <label>Your current password:
        <input type="password" name="opassword" value="" placeholder="Enter your current password"/>
    </label>
</div>
<div>
    <label>New password:
        <input type="password" name="password" value="" placeholder="At least 8 characters"/>
    </label>
</div>
<div>
    <label>New password confirm:
        <input type="password" name="passconf" value="" placeholder="Enter your new password again"/>
    </label>
</div>
<div><input type="submit" value="Save" /></div>
<p><?php echo anchor('user/setting', 'Back'); ?></p>

</form>