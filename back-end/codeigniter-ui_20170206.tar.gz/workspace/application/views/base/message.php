<div class="contents">
	<div class="grid_wrapper">

		<div class="g_12 contents_header">
			<h3 class="i_16_forms tab_label"><?=$message?></h3>
		</div>
		<div class="g_12 contents_header">
			<a href="javascript:history.back(-1)">Back</a>
		</div>
	</div>
</div>