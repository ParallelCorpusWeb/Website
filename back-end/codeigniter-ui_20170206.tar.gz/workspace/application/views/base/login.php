<!DOCTYPE html>
<html lang="en">
    
<head>
        <title>CPE LABORATOYR</title>
        <link rel="icon" type="image/jpg" href="/Images/lab_icon_favicon.png" />
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="/CSS/bootstrap.min.css" />
		<link rel="stylesheet" href="/CSS/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="/CSS/maruti-login.css" />
    </head>
    <body>
        <div id="logo">
        </br></br></br></br>
            <img src="/Images/logo.png" alt=""  style="width:150%" />
        </div>
        <div id="loginbox">
        <?php echo form_open('user/login','class="form-vertical" id="loginform"'); ?>
            <!--<form id="loginform" class="form-vertical">-->
				 <div class="control-group normal_text"><h3>Login</h3></div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-user"></i></span><input type="text" id="username" name="username" placeholder="Username" required autofocus title="123456789@ipm.edu.mo"/>
                            <p id="emailError" style="color:red;"></p>
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-lock"></i></span><input type="password" id="password" name="password" placeholder="Password" required />
                            <p id="pwError" style="color:red;"></p>
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span class="pull-left">
                        <!--<a href="#" class="flip-link btn btn-warning" id="to-recover">register a new account.</a>-->
                        <?=anchor('#','Create a new account.',array('class'=>'flip-link btn btn-warning','id'=>'to-recover'));?>
                    </span>
                    <span class="pull-right"><input type="submit" class="btn btn-success" value="Login" /></span>
                </div>
            </form>
            <form id="recoverform" action="#" class="form-vertical">
				<p class="normal_text">Enter your e-mail address below and we will send you instructions <br/><font color="#FF6633">how to recover a password.</font></p>
				
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on"><i class="icon-envelope"></i></span><input type="text" placeholder="E-mail address" />
                        </div>
                    </div>
               
                <div class="form-actions">
                    <span class="pull-left"><a href="#" class="flip-link btn btn-warning" id="to-login">&laquo; Back to login</a></span>
                    <span class="pull-right"><input type="submit" class="btn btn-info" value="Recover" /></span>
                </div>
            </form>
        </div>
        
        <script src="Javascript/Login/jquery.min.js"></script>  
        <script src="Javascript/Login/maruti.login.js"></script> 

    </body>

</html>