    

    </div>
    <footer>
		<div class="wrapper">
			<span class="copyright">
				© 2016 Macao Polytechnic Institute. All Rights Reserved. Designed By Macao Polytechnic Institute
			</span>
		</div>
	</footer>
</body>
</html>