<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'security'));
        $this->load->model('file_model');
        $this->load->model('task_model');
	    if(!$this->session->userdata('user')){
                redirect('/user');
        }
    }
	 
	public function index()
	{
	    $uid=$this->session->userdata('user')->uid;
	    $data['tasks']=$this->task_model->getAllBy($uid);
	    $data['numOfTasks']=$this->task_model->countDoingTasks($uid);
		$data['title']="Tasks";
		$this->load->helper('url');
		$this->load->view('base/_header',$data);
		$this->load->view('tasks/list',$data);
		$this->load->view('base/_footer');
	}
	
	public function take()
	{
	    $rid=$this->input->post('rid');
	    getTask($rid);
	}
	
	public function getTask($rid){
	    $uid=$this->session->userdata('user')->uid;
		if($this->task_model->getDoer($rid)){
	    	$this->message('Notice','This task has been taken by someone.');
	    }else if($this->task_model->countDoingTasks($uid)<5){
	    	$this->task_model->insert($uid,$rid);
        	$this->file_model->update($rid,"Processing");
        	$this->message('Success','Take task successfully.');
	    }else{
        	$this->message('Notice','You can only task 5 tasks at the same time.');
	    }
	}
	
	public function message($title,$message){
		$data['title']=$title;
		$data['message']=$message;
		$this->load->view('base/_header',$data);
		$this->load->view('base/message',$data);
		$this->load->view('base/_footer');
	}
	
	public function submit()
	{
		if($this->input->post('action')=='Submit')
		{
			$sentences=$this->input->post('sentences');
			$total=0;
			$finish=0;
			foreach($sentences as $sentence){
				if($sentence['status']!=0){
					$finish++;
				}
				$total++;
			}
			$percentage= floor(10000*$finish/$total)/100;
			
			$rid=$this->input->post('rid');
			$json=json_encode($sentences);
			if($percentage<100){
				$this->task_model->saveJSON($rid,$json,$percentage);
			}else{
				$this->task_model->finishWork($rid,$json,$percentage,$sentences);
			}
	        $this->message('Success','Your work is submitted successfully.');
		}
		elseif($this->input->post('action')=='Reset')
		{
			$rid=$this->input->post('rid');
			$this->task_model->resetWork($rid);
			redirect('/file/details/'.$rid);
		}
	}
}


    