<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	 
	public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                if(!$this->session->userdata('user')){
                        redirect('/user');
                }
        }

        public function index()
        {
		$data['title']="Upload files";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_form', array('error' => ' ' ));
		$this->load->view('base/_footer');
        }

        public function showError($err)
        {
                $data['title']="Upload files";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_form', array('error' => $err));
		$this->load->view('base/_footer');
        }
        
        public function showSuccess($data)
        {
                $data['title']="Upload success";
                $this->load->view('base/_header',$data);
                $this->load->view('uploader/upload_success', $data);
		$this->load->view('base/_footer');
        }

        public function do_upload()
        {
                $filename_cn=$_FILES['cn']['name'];
                $filename_pt=$_FILES['pt']['name'];
                $ext_cn=strtoupper(PATHINFO($filename_cn,PATHINFO_EXTENSION));
                $ext_pt=strtoupper(PATHINFO($filename_pt,PATHINFO_EXTENSION));
                $file_cn=$_FILES['cn']['tmp_name'];
                $file_pt=$_FILES['pt']['tmp_name'];
                if(empty($filename_cn)&&empty($filename_pt)){
                        $this->showError('<p>Please select txt files to upload.</p>');
        		return;
                }
                
                $allow_types=['TXT'];
                if(!in_array($ext_cn,$allow_types)||!in_array($ext_pt,$allow_types)){
                        $this->showError('<p>Sorry. Only allow '.implode(", ",$allow_types).' file.</p>');
        		return;
                }
                
                $cn=file_get_contents($file_cn);
                $pt=file_get_contents($file_pt);
                $data['upload_file'][]=array('category'=>'Chinese','name'=>$filename_cn);
                $data['upload_file'][]=array('category'=>'Portuguese','name'=>$filename_pt);
        
        //remove duplicate useless data   
                $cn = str_replace('a name=\"fb_share\" ></a<table width=\"600\" height=\"25\">Twittera name=\"fb_share\" ></a','',$cn);
                $pt = str_replace('a name=\"fb_share\" ></a<table width=\"600\" height=\"25\">Twittera name=\"fb_share\" ></a','',$pt);
                $cn = str_replace("\\r\\n",chr(13).chr(10),$cn);
                $pt = str_replace("\\r\\n",chr(13).chr(10),$pt);
                
        //split by enter (s0)
                $s0_pt=explode(chr(13).chr(10),$pt);
                $s0_cn=explode(chr(13).chr(10),$cn);
                // var_dump(count($s0_pt),count($s0_cn));
                
                $count=count($s0_pt)<=count($s0_cn)?count($s0_pt):count($s0_cn);
                $max_count=count($s0_pt)>=count($s0_cn)?count($s0_pt):count($s0_cn);
                $s1_pt=[];$s1_cn=[];
                for($i=0;$i<$count;$i++){
                        // var_dump($s0_pt[$i],$s0_cn[$i]);
                //split by .。 (s1)
                        $s0_pt[$i]=str_replace('. ','. #**#',$s0_pt[$i]);
                        $s0_cn[$i]=str_replace('。','。#**#',$s0_cn[$i]);
                        array_push($s1_pt,explode("#**#",$s0_pt[$i]));
                        array_push($s1_cn,explode("#**#",$s0_cn[$i]));
                }
                for(;$i<$max_count;$i++){
                        if(count($s0_pt)==$max_count){
                                $s0_pt[$i]=str_replace('. ','. #**#',$s0_pt[$i]);
                                array_push($s1_pt,explode("#**#",$s0_pt[$i]));
                        }
                        if(count($s0_cn)==$max_count){
                                $s0_cn[$i]=str_replace('。','。#**#',$s0_cn[$i]);
                                array_push($s1_cn,explode("#**#",$s0_cn[$i]));
                        }
                }
                
                $count=count($s1_pt)<=count($s1_cn)?count($s1_pt):count($s1_cn);
                $max_count=count($s1_pt)>=count($s1_cn)?count($s1_pt):count($s1_cn);
                
                
                $i=0;
                $bi="";
                for(;$i<$count;$i++){
                        for(;count($s1_pt[$i])>0||count($s1_cn[$i])>0;){
                                if(count($s1_pt[$i])>0){
                                        $bi.=array_shift($s1_pt[$i]).chr(13).chr(10);
                                }
                                if(count($s1_cn[$i])>0){
                                        $bi.=array_shift($s1_cn[$i]).chr(13).chr(10);
                                }
                        }
                        $bi.=chr(13).chr(10);
                }
                
                if(count($s1_cn)==$max_count){
                        for(;$i<$max_count;$i++){
                                for(;count($s1_cn[$i])>0;){
                                        if(count($s1_cn[$i])>0){
                                                $bi.=array_shift($s1_cn[$i]).chr(13).chr(10);
                                        }
                                }
                                $bi.=chr(13).chr(10);
                        }
                }else{
                        for(;$i<$max_count;$i++){
                                for(;count($s1_pt[$i])>0;){
                                        if(count($s1_pt[$i])>0){
                                                $bi.=array_shift($s1_pt[$i]).chr(13).chr(10);
                                        }
                                }
                                $bi.=chr(13).chr(10);
                        }
                }
                
                
                // var_dump($bi);
                
        //upload success
                //save to db        
		$this->load->model('file_model');
                $this->file_model->insert($cn,$pt,$bi);
                
                //show success
                $this->showSuccess($data);
                
        }
	
}


    