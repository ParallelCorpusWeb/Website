<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Internal extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'security'));
        $this->load->model('file_model');
        $this->load->model('task_model');
        $this->load->model('user_model');
	    // if(!$this->session->userdata('user')){
     //           redirect('/user');
     //   }
    }
	 
	public function index()
	{
	    // if(!$this->session->userdata('user')){
            
    	    $data['users']=$this->user_model->getAll();
    	    $data['tasks']=$this->task_model->getAll();
    		$this->load->helper('url');
    		$this->load->view('internal/index_admin',$data);
      //  }else if($this->session->userdata('user')->authority=="teacher"){
      //      $uid=$this->session->userdata('user')->uid;
    	 //   $data['tasks']=$this->task_model->getAllBy($uid);
    		// $data['title']="Tasks";
    		// $this->load->helper('url');
    		// $this->load->view('internal/index_teacher',$data);
      //  }
         
	    
	    
	}
	
	
	public function message($title,$message){
		$data['title']=$title;
		$data['message']=$message;
		$this->load->view('base/_header',$data);
		$this->load->view('base/message',$data);
		$this->load->view('base/_footer');
	}
	
}


    