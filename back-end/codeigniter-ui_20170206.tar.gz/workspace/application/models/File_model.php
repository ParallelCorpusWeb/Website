<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_model extends CI_Model {
	
	private $table='raw';
	
	public function __construct()
    {
            parent::__construct();
    }

    public function getAll()
    {
        //$query= $this->db->get($this->table);
        //return $query->result();
        $this->db->select('raw.rid,raw.status,task.start_at,task.percentage');
        $this->db->from('raw');
        $this->db->join('task', 'raw.rid = task.rid','left');
        
        $query = $this->db->get();
        return $query->result();
    }

    public function get($id){
        // $query= $this->db->get_where($this->table, array('rid' => $id));
        // return $query->row();
        $this->db->select('raw.rid,raw.chinese,raw.portuguese,raw.bilingual,task.percentage,task.start_at,task.end_at,task.bilingual_after');
        $this->db->from('raw');
        $this->db->join('task', 'raw.rid = task.rid','left');
        $this->db->where('raw.rid',$id);
        
        $query = $this->db->get();
        return $query->row();
    }
    
    public function insert($cn,$pt,$bi){
        $cn=$this->db->escape_str($cn);
        $pt=$this->db->escape_str($pt);
        $bi=$this->db->escape_str($bi);
        $this->db->insert($this->table, array('chinese'=>$cn,'portuguese'=>$pt,'bilingual'=>$bi));
    }
    
    public function update($rid,$status){
        $status=$this->db->escape_str($status);
        $rid=$this->db->escape_str($rid);
        $this->db->where('rid', $rid);
        $this->db->update($this->table, array('status'=>$status));
        
    }
    
    public function delete($id){
        $id=$this->db->escape_str($id);
        $this->db->delete($this->table, array('rid' => $id));
    }
    
    public function clear(){
        $this->db->truncate($this->table);
    }
        
}


    